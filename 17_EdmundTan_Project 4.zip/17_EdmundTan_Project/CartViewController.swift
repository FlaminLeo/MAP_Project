//
//  CartViewController.swift
//  17_EdmundTan_Project
//
//  Created by CCIAD3 on 1/3/22.
//  Copyright © 2022 ITE. All rights reserved.
//

import UIKit

class CartViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    @IBOutlet var cartDisplay: UITableView!
    var loggedUser = UserDefaults.standard.string(forKey: "user")
    var cartProducts: [Cart]!
    var price: [Cart]!
    @IBOutlet var priceLabel: UILabel!
    @IBOutlet var discountLabel: UILabel!
    @IBOutlet var totalLabel: UILabel!
    var discount = Int16()
    @IBAction func checkOutBtn(_ sender: Any) {
        performSegue(withIdentifier: "toCheckout", sender: nil)
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return cartProducts.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cartCell", for: indexPath) as! CartTableViewCell
        
        cell.cartImg.image = UIImage(named: cartProducts[indexPath.row].productImg ?? "")
        
        cell.cartProdName.text = cartProducts[indexPath.row].productName
        
        cell.cartProdPrice.text = String(cartProducts[indexPath.row].productPrice)

        cell.cartProdAmount.text = String(cartProducts[indexPath.row].prodAmount)
        return cell
    }
    
    
    override func becomeFirstResponder() -> Bool {
        return true
    }

    override func motionEnded(_ motion: UIEvent.EventSubtype, with event: UIEvent?){
        if motion == .motionShake {
            print("Shake Gesture Detected")
            //show some alert here
            discount = Int16.random(in: 1..<20)
            let alert = UIAlertController(title: "Alert", message: "Discount granted", preferredStyle: UIAlertController.Style.alert)
            
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil))
            
            self.present(alert, animated: true)
            
            discountLabel.text = "Discount: \(String(discount))"
            
            totalLabel.text = "Total: \(String(totalPrice - (totalPrice/discount)))"

            
        }
    }

    
    @objc func refresh() {
        self.cartDisplay.reloadData() // a refresh the tableView.
    }

    
    override func viewDidLoad() {
        super.viewDidLoad()
        cartDisplay.delegate = self
        cartDisplay.dataSource = self
        // Do any additional setup after loading the view.
        cartProducts = retrieveSpecificCart(Name: loggedUser ?? "")
        price = getPrice(Name: loggedUser ?? "")
        
        priceLabel.text = "Price: \(String(totalPrice))"
        
        discountLabel.text = "Discount: \(String(discount))"
        
        totalLabel.text = "Total: \(String(totalPrice))"
        
        let layer = CAGradientLayer()
        
               layer.frame = view.bounds
               layer.colors = [UIColor.white.cgColor, UIColor.orange.cgColor]
               layer.startPoint = CGPoint(x: 1, y: 1)
               layer.endPoint = CGPoint(x: 0.5, y: 1.9)
               
               view.layer.addSublayer(layer)
               view.layer.insertSublayer(layer, at: 0)
               
               viewContext = app.persistentContainer.viewContext
               if !(UserDefaults.standard.object(forKey: "check") != nil) {
                   UserDefaults.standard.setValue(0, forKey: "check")
                   initializeData()
               }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        NotificationCenter.default.addObserver(self, selector: #selector(self.refresh), name: NSNotification.Name(rawValue: "newDataNotif"), object: nil)
        cartProducts = retrieveSpecificCart(Name: loggedUser ?? "")
        self.cartDisplay.reloadData()
        
    }

    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
               if segue.identifier == "toCheckout" {
             let productDetail = segue.destination as! CheckoutViewController
                productDetail.totalPrice = Int16(totalLabel.text!)
                    
        }
    }


}
