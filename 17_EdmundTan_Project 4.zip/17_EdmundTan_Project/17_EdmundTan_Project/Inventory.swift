//
//  Inventory.swift
//  17_EdmundTan_Project
//
//  Created by CCIAD3 on 22/2/22.
//  Copyright © 2022 ITE. All rights reserved.
//

import UIKit
func initializeData() {
    
    addCategory(Name: "CPU", ID: 1, Desc: "The CPU is the brain of a computer, containing all the circuitry needed to process input, store data, and output results", Img: "cpu_category")
    
    addCategory(Name: "GPU", ID: 2, Desc: "The CPU is the brain of a computer, containing all the circuitry needed to process input, store data, and output results", Img: "gpu_category")
    
    addCategory(Name: "Motherboard", ID: 3, Desc: "The CPU is the brain of a computer, containing all the circuitry needed to process input, store data, and output results", Img: "motherboard_category")
    
    addCategory(Name: "Memory", ID: 4, Desc: "The CPU is the brain of a computer, containing all the circuitry needed to process input, store data, and output results", Img: "memory_category")

    addCategory(Name: "Storage", ID: 5, Desc: "The CPU is the brain of a computer, containing all the circuitry needed to process input, store data, and output results", Img: "storage_category")
    
    addProduct(Name: "AMD Ryzen 5 5600X 3.7 GHz Six-Core AM4 Processor", ID: 1, CatID: 1, Desc: "Power up your computing experience with the AMD Ryzen 5 5600X 3.7 GHz Six-Core AM4 Processor, which features six cores and 12 threads to help quickly load and multitask demanding applications. Designed for socket AM4 motherboards using the powerful Zen 3 architecture, the 7nm 5th generation Ryzen processor offers significantly improved performance compared to its predecessor. With a base clock speed of 3.7 GHz and a max boost clock speed of 4.6 GHz in addition to 32MB of L3 Cache, the Ryzen 5 5600X is built to deliver the performance needed to smoothly handle tasks ranging from content creation to immersive gaming experiences. Other features include support for PCIe Gen 4 technology and 3200 MHz DDR4 RAM with compatible motherboards. This processor has a 65W TDP (Thermal Design Power) and includes a Wraith Stealth cooling solution. Please note that it does not have an integrated GPU, so a dedicated graphics card is required.", Img: "AMD Ryzen 5 5600X", Price: 200)
    
    addProduct(Name: "Intel Core i9-12900K - Core i9 12th Gen Alder Lake 16-Core 3.2 GHz", ID: 2, CatID: 1, Desc: "Revolutionary performance and multitasking. With the highest clock speeds and a groundbreaking new architecture, you’ll be able to push your gameplay to new heights while secondary apps run seamlessly in the background.", Img: "intelcpu1", Price: 200)
    
    addProduct(Name: "Intel Core i5-11600K - Core i5 11th Gen Rocket Lake 6-Core 3.9 GHz", ID: 3, CatID: 1, Desc: "Free your build.11th Gen Intel® Core™ processors support the latest platform technologies to truly personalize your new PC's capabilities. PCIe Gen 4:Support for the latest discrete graphics cards and other PCIe devicesIntel® Killer™ Wi-Fi 6/6E (Gig+) technology: Automatically prioritizes play on your busy networks 3 Thunderbolt™ 4 technology: Fast connectivity to monitors and other peripherals To benefit from these technologies, ensure applicable system components are compatible.", Img: "intelcpu2", Price: 200)
    
    addProduct(Name: "AMD Ryzen 7 5700G - Ryzen 7 5000 G-Series Cezanne (Zen 3) 8-Core 3.8 GHz", ID: 4, CatID: 1, Desc: "Be unstoppable with the unprecedented speed of the AMD Ryzen™ 5000 G-Series desktop processors, whether you’re playing the latest games, designing the next skyscraper, or crunching scientific data. With AMD Ryzen™ desktop processors, you’re in the lead.", Img: "amdcpu2", Price: 200)
    
    addProduct(Name: "AMD Ryzen 7 5800X - Ryzen 7 5000 Series Vermeer (Zen 3) 8-Core 3.8 GHz", ID: 5, CatID: 1, Desc: "THE BEST PROCESSOR FOR THE BEST GAMING OS \n\n Ultimate performance. Seamless compatibility. Get an incredible Windows 11 gaming experience with AMD Ryzen™ Processors.", Img: "amdcpu3", Price: 200)
    
    addProduct(Name: "AMD Ryzen 9 5900X - Ryzen 9 5000 Series Vermeer (Zen 3) 12-Core 3.7 GHz", ID: 6, CatID: 1, Desc: "THE BEST PROCESSOR FOR THE BEST GAMING OS \n\n Ultimate performance. Seamless compatibility. Get an incredible Windows 11 gaming experience with AMD Ryzen™ Processors.", Img: "amdcpu4", Price: 200)
    
    addProduct(Name: "ASUS Phoenix GeForce RTX 3050 8GB GDDR6", ID: 1, CatID: 2, Desc: "GET FASTER PERFORMANCE WITH NVIDIA DLSSMAX FPS. MAX QUALITY. POWERED BY AI. Get a performance boost with NVIDIA DLSS (Deep Learning Super Sampling). AI-specialized Tensor Cores on GeForce RTX GPUs give your games a speed boost with uncompromised image quality. This lets you crank up the settings and resolution for an even better visual experience.", Img: "gpu1", Price: 200)
    
    addProduct(Name: "ASUS Dual GeForce RTX 3050 8GB GDDR6", ID: 1, CatID: 2, Desc: "GET FASTER PERFORMANCE WITH NVIDIA DLSSMAX FPS. MAX QUALITY. POWERED BY AI. Get a performance boost with NVIDIA DLSS (Deep Learning Super Sampling). AI-specialized Tensor Cores on GeForce RTX GPUs give your games a speed boost with uncompromised image quality. This lets you crank up the settings and resolution for an even better visual experience.", Img: "gpu2", Price: 200)
    
    addProduct(Name: "ASUS ROG Strix GeForce RTX 3050 8GB GDDR6", ID: 1, CatID: 2, Desc: "GET FASTER PERFORMANCE WITH NVIDIA DLSSMAX FPS. MAX QUALITY. POWERED BY AI. Get a performance boost with NVIDIA DLSS (Deep Learning Super Sampling). AI-specialized Tensor Cores on GeForce RTX GPUs give your games a speed boost with uncompromised image quality. This lets you crank up the settings and resolution for an even better visual experience.", Img: "gpu3", Price: 200)
}
