//
//  DetailViewController.swift
//  17_EdmundTan_Project
//
//  Created by CCIAD3 on 1/3/22.
//  Copyright © 2022 ITE. All rights reserved.
//

import UIKit
import CoreData

class DetailViewController: UIViewController {
    
    let app = UIApplication.shared.delegate as! AppDelegate
    var viewContext: NSManagedObjectContext!
    var user = UserDefaults.standard.string(forKey: "user")
    
    var categoryID = Int16()
    var productID = Int16()
    var productRetrieve: [Products]!
    var addProdtoCart: [Cart]!
    
    @IBOutlet var productImg: UIImageView!
    @IBOutlet var productTitle: UILabel!
    @IBOutlet var productDesc: UILabel!
    @IBOutlet var productAmount: UITextField!
    @IBOutlet var productPrice: UILabel!
    @IBOutlet var amount: UIStepper!
    
    @IBAction func productStepper(_ sender: UIStepper) {
        productAmount.text = "\(Int(amount.value))"
    }
    
    @IBAction func addToCart(_ sender: Any) {
                addProductToCart()
//            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "newDataNotif"), object: nil)
//        let fetchRequest: NSFetchRequest<Cart> = Cart.fetchRequest()
//
//        let predicate = NSPredicate(format: "userName = '" + (user ?? "") + "'")
//
//        fetchRequest.predicate = predicate
//
//        do {
//            let userCart = try viewContext.fetch(fetchRequest)
//
//            if userCart.isEmpty {
//                if Int(productAmount.text!)! != 0 || productAmount.text != nil || Int(productAmount.text!)! <= 0 {
//                    addProductToCart()
//                }else {
//                    let alert = UIAlertController(title: "Error", message: "Please enter a valid amount", preferredStyle: UIAlertController.Style.alert)
//
//                    alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil))
//
//                    self.present(alert, animated: true)
//                }
//            }else {
//                if Int(productAmount.text!)! != 0 || productAmount.text != nil || Int(productAmount.text!)! <= 0{
//                        addProductToCart()
//                }else {
//                    for cartProd in userCart {
//
//                    if cartProd.productID == productRetrieve[0].productID {
//
//                            let alert = UIAlertController(title: "Error", message: "Item already in cart", preferredStyle: UIAlertController.Style.alert)
//
//                                  alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil))
//
//                                  self.present(alert, animated: true)
//                        }else {
//                            let alert = UIAlertController(title: "Error", message: "Please enter a valid amount", preferredStyle: UIAlertController.Style.alert)
//
//                                alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil))
//
//                                self.present(alert, animated: true)
//                        }
//                    }
//                }
//            }
//        }catch {
//            print(error)
//        }
    }
    
    func addProductToCart() {
        if productAmount.text != String(0) || productAmount.text != nil {
            
            let products = NSEntityDescription.insertNewObject(forEntityName: "Cart", into: viewContext) as! Cart
              
            products.productName = productTitle.text
            products.productID = productRetrieve[0].productID
            products.productCatID = productRetrieve[0].productCategoryID
            products.productDesc = productDesc.text
            products.productImg = productRetrieve[0].productImage
            products.productPrice = productRetrieve[0].productPrice
            products.prodAmount = Int16(productAmount.text!)!
            products.userName = user
              
            let alert = UIAlertController(title: "Alert", message: "Item added to cart", preferredStyle: UIAlertController.Style.alert)
                           
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil))
                           
                self.present(alert, animated: true)
                
            app.saveContext()
            
        }else {
            let alert = UIAlertController(title: "Error", message: "Please enter a valid amount", preferredStyle: UIAlertController.Style.alert)
            
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil))
            
            self.present(alert, animated: true)
        }
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        productRetrieve = retrieveSpecificProduct(ID: productID, CatID: categoryID)
        productImg.image = UIImage(named: productRetrieve[0].productImage!)
        productTitle.text = productRetrieve[0].productName
        productDesc.text = productRetrieve[0].productDescription
        productPrice.text = String(productRetrieve[0].productPrice)
        
        viewContext = app.persistentContainer.viewContext
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
