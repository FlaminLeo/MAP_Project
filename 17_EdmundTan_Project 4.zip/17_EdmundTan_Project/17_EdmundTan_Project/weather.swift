//
//  weather.swift
//  17_EdmundTan_Project
//
//  Created by CCIAD3 on 1/3/22.
//  Copyright © 2022 ITE. All rights reserved.
//

import Foundation

struct weather:Codable {
    let weather: [resultsArray]
    struct resultsArray: Codable {
        let main: String?
        let id:Int?
        let description:String?
    }
}
