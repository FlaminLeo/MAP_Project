//
//  CartTableViewCell.swift
//  17_EdmundTan_Project
//
//  Created by CCIAD3 on 1/3/22.
//  Copyright © 2022 ITE. All rights reserved.
//

import UIKit

class CartTableViewCell: UITableViewCell {

    @IBOutlet var cartImg: UIImageView!
    @IBOutlet var cartProdName: UILabel!
    @IBOutlet var cartProdPrice: UILabel!
    @IBOutlet var cartProdAmount: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
