
//
//  CheckoutViewController.swift
//  17_EdmundTan_Project
//
//  Created by CCIAD3 on 1/3/22.
//  Copyright © 2022 ITE. All rights reserved.
//

import UIKit
import CoreLocation

class CheckoutViewController: UIViewController {
    var retrieveUser:User!
    var user = UserDefaults.standard.string(forKey: "user")
    var totalPrice:Int16!
    var credits:Int16!
    var address:String!
    let geoCoder = CLGeocoder()
    @IBOutlet var payableLbl: UILabel!
    @IBOutlet var creditsLbl: UILabel!
    @IBOutlet var addressLbl: UILabel!
    @IBOutlet var timeLbl: UILabel!
    @IBOutlet var payBtn: UIButton!
    
    
    @IBAction func goToAdresss(_ sender: Any) {
        performSegue(withIdentifier: "fromAddressList", sender: nil)
    }
    
    @IBAction func unwindToCheckout(segue:UIStoryboardSegue) {
        
        addressLbl.text = UserDefaults.standard.string(forKey: "Address")
        
         if segue.identifier == "fromAddressList" {
             addressLbl.text = address ?? "Error getting address"
             timeLbl.text = "Getting weather info..."
             geoCoder.geocodeAddressString(address) {
                 (placemarks, error) in
                 guard
                     let placemarks = placemarks,
                     let location = placemarks.first?.location
                 else {
                     self.timeLbl.text = "Error getting coodinates from address"
                     return
                 }
                 
                 let urlstring = "https://api.openweathermap.org/data/2.5/weather?lat=\(location.coordinate.latitude)&lon=\(location.coordinate.longitude)&appid=e9f18d64f984b52a1ff628c4b46aa0f3"
                 print("URL: " + urlstring)
                 let url:URL = URL(string: urlstring)!
                 var weatherDescriptor:String = ""
                 
                 let task = URLSession.shared.dataTask(with: url) {(data, response, error) in
                     guard let dataResponse = data,
                         error == nil else {
                         print(error?.localizedDescription ?? "Response Error")
                         self.timeLbl.text = "Error in API response"
                         return
                     }
                     do{
                         let decoder = JSONDecoder()
                         let model = try decoder.decode(weather.self, from: dataResponse)
                         if model.weather[0].main == "Rain" {
                             weatherDescriptor = "Bad Weather Condition\nNext Day"
                         } else {
                             weatherDescriptor = "\((model.weather[0].description)?.capitalized ?? "Unknown")\nSame Day"
                         }
                     }
                     catch let parsingError {
                         print("Error", parsingError)
                     }
                     
                     DispatchQueue.main.async {
                         self.timeLbl.text = weatherDescriptor
                     }
                 }
                 task.resume()
             }
         }
    }
        
    override func viewDidLoad() {
        super.viewDidLoad()
        retrieveUser = retrieveWelcome(Username: user ?? "")
        
        payableLbl.text = String(retrieveUser.credits)
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
